//
//  CreateAccountViewController.swift
//  Car_Parking_App
//
//  Created by mithun koroth on 2021-01-26.
//

import UIKit

class CreateAccountViewController: UIViewController {
    
    @IBOutlet var email: UITextField!
    @IBOutlet var password: UITextField!
    @IBOutlet var confirmPassword: UITextField!
    
    
    let accountController = AccountController()

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func createAccount(){
        // validate here
        let pwd = self.password.text
        let confirmPwd = self.password.text
        
        if (pwd == confirmPwd){
            let emailAdd = self.email.text ?? "unkown"
            
            let insertionStatus = self.accountController.insertAccount(email: emailAdd, password: pwd!)
            
            
            //
            switch insertionStatus {
            case .INSERT_SUCCESS:
                print(#function, "account is created")
                self.navigationController?.popViewController(animated: true)
            case .USER_EXISTS:
                print(#function,"User with the same email already exists")
                
            case .INSERT_FAILURE:
            print(#function, "Unable to create email address, try again later")
            }
        
            
            
        }else{
            print(#function, "both passwords must be the same")
        }
        
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
