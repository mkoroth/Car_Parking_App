//
//  ViewController.swift
//  Car_Parking_App
//
//  Created by mithun koroth on 2021-01-26.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet var email :  UITextField!
    @IBOutlet var password: UITextField!
    let accountController = AccountController ()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        accountController.getAllAccounts()
    }
    @IBAction func doSignIn(){
        print(#function, "Sign in clicked")
        
        if (email.text != nil && password.text != nil){
            if (self.accountController.validateAccount(email: email.text!, password: password.text!)){
                print(#function, "Login successful")
                self.loginSuccessful()
            }else{
                let alert = UIAlertController(title: "Login Unsuccessful", message: "Incorrect emai", preferredStyle: .alert)
                
                alert.addAction(UIAlertAction(title: NSLocalizedString("OK", comment: "default action"), style:  .default, handler: nil))
                self.present(alert, animated: true, completion: nil)
                    
                
            }
        }
        
    }
    func loginSuccessful(){
        UserDefaults.standard.setValue(email.text, forKey: "mk.usermail")
        
        let alert = UIAlertController(title: "Login Successful", message: "you have logged in now", preferredStyle: .alert   )
        
        alert.addAction(UIAlertAction(title: NSLocalizedString("OK", comment: "default action"), style: .default, handler: {_ in
            
            print("function", "Navigatin to home home")
            
            let storyboard = UIStoryboard(name: "Main", bundle: Bundle.main)
            let tabContainer = storyboard.instantiateViewController(withIdentifier: "TabContainer")
            
            self.navigationController?.pushViewController(tabContainer, animated:true)
        }))
        
        self.present(alert, animated:true, completion: nil)
    }


}

