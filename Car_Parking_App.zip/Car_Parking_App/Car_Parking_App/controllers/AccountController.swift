//
//  AccountController.swift
//  Car_Parking_App
//
//  Created by mithun koroth on 2021-01-26.
//

import Foundation
import CoreData
import UIKit
class AccountController{
    private var moc :NSManagedObjectContext
    init(){
        
        self.moc = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    }
    
    func insertAccount(email: String, password: String) -> AccountStatus{
        
       
        
        do{
            let newAccount = NSEntityDescription.insertNewObject(forEntityName: "Account", into: moc) as! Account
            
            newAccount.dateCreated = Date()
            newAccount.isActive = true
            newAccount.email = email
            newAccount.password = password
                       
            
            try moc.save()
            print(#function, "Account is created")
            return AccountStatus.INSERT_SUCCESS
            
        }catch let error as NSError{
            print(#function, "something went wrong")
            print(#function, error.localizedDescription)
            return AccountStatus.INSERT_FAILURE
        }
                
    }
    
    func getAllAccounts(){
        let fetchRequest = NSFetchRequest<Account>(entityName: "Account")
        
        do{
            let result = try moc.fetch(fetchRequest)
            let accountList = result as  [Account]
            
            for account in accountList{
                print("Email \(account.email) Password \(account.password) DateCreated\(account.dateCreated) isActive \(account.isActive)")
            }
        }catch let error{
            print(#function,"could not fetch records", error.localizedDescription)
        }
    }
    func validateAccount(email : String, password: String ) ->Bool{
        
        
        let accountToValidate = self.searchAccount(email: email)
        if accountToValidate != nil{
            if (accountToValidate!.password == password && accountToValidate!.isActive){
                return true
            }
            
        }
        return false
        
    }
    func searchAccount(email: String) -> Account?{
        let fetchRequest = NSFetchRequest<Account>(entityName: "Account")
        let predicate = NSPredicate(format: "email == %@", email)
        
        fetchRequest.predicate = predicate
        do{
            let result = try moc.fetch(fetchRequest).first
            if result != nil {
                print(#function, "Matching account found with email \(email)")
                
                let account = result as!Account
                return account
                
            }
            
        }catch let error{
            print(#function, error.localizedDescription)
        }
        print(#function, "NO ACCOUNT FOUND FOR THE GIVEN EMAIL \(email)")
        return nil
    }
    
}
enum AccountStatus {
    case INSERT_SUCCESS
    case USER_EXISTS
    case INSERT_FAILURE
}
